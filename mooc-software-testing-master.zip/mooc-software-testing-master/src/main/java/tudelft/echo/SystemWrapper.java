package tudelft.echo;

public class SystemWrapper {

    void print(String arg) {
        System.out.print(arg);
    }

    void exit(int code) {
        System.exit(code);
    }
}
