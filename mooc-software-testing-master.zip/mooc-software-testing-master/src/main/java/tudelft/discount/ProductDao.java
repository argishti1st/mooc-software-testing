package tudelft.discount;

import java.util.List;

public interface ProductDao {
    List<Product> all();
}
