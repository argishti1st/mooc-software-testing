package tudelft.christmas;

import java.util.Calendar;

public interface Clock {
    Calendar now();
}
